var dataz = new Object();
	
	dataz['Question 1'] = ['What Type of Instrument Do You Want to Add to the Band?', 'Brass', 'Woodwind', 'Percussion', 'String'];
	dataz['Brass'] = ['Valved or Sliding?', 'Valved', 'Sliding'];
	dataz['Valved'] = ['Select Your Instrument', 'Trumpet', 'French Horn', 'Tuba'];
	dataz['Sliding'] = ['Select Your Instrument', 'Trombone'];
	dataz['Woodwind'] = ['Select Your Instrument', 'Flute', 'Piccolo', 'Oboe', 'Clarinet', 'Bassoon', 'Saxophone'];
	dataz['Percussion'] = ['Tuned or Untuned?', 'Tuned', 'Untuned']; 
	dataz['Tuned'] = ['Select Your Instrument', 'Steel Drums', 'Marimba', 'Hang Drum', 'Xylophone']; 
	dataz['Untuned'] = ['Select Your Instrument', 'Snare', 'Cymbal', 'Cowbell', 'Bongo'];
	dataz['String'] = ['How Many Strings?', 'Four', 'Six', 'Other'];
	dataz['Four'] = ['Select Your Instrument', 'Bass Guitar', 'Cello', 'Violin', 'Fiddle'];
	dataz['Six'] = ['Select Your Instrument', 'Guitar', 'Dobro'];
	dataz['Other'] = ['Select Your Instrument', 'Banjo', 'Mandolin', 'Lute', 'Sitar'];

