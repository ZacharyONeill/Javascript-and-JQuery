README

Things I am aware do not work, (mainly to cut down your code-searching time)

No IE7
No local storage
Some problems with the form on submition
instruments are not stored for next visit